//
//  EzFlatApp.swift
//  EzFlat
//
// Created by Juan Salgado, Dennis Corral, Matthew Robinson.
//
//

import SwiftUI

@main
struct EzFlatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
